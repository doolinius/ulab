#!/bin/sh

echo "flag_5599"
